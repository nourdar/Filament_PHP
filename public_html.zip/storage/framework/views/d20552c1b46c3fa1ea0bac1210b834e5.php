<nav class=" border-gray-200 bg-slate-900 font-diph w-full "
    <?php if(isset($settings?->style[0])): ?> style="<?php echo e('background-color:' . $settings?->style[0]['navbar_bgcolor']); ?>" <?php endif; ?>>
    <div class="max-w-screen-xl flex flex-wrap items-center justify-center mx-auto p-4">
        <a aria-label="Link to home page" href="/" class="flex items-center space-x-3 rtl:space-x-reverse">
            <a aria-label="Link to home page" class="ml-5 flex items-center text-white" href="/">
                <img src="<?php echo e(asset('storage/' . $settings?->logo)); ?>" alt="Logo" class="mr-5"
                    style="max-width: 200px; max-height:80px">
                <span class="hidden md:block text-4xl text-bold" style="font-weight: 600">
                    <?php echo e($settings?->name); ?>

                </span>
            </a>
        </a>
        
        <div class="hidden w-full md:block md:w-auto" id="navbar-default">

        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/shop/components/nav.blade.php ENDPATH**/ ?>