<?php if(isset($showAll) && $showAll): ?>
    <?php echo $__env->make('shop.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<!--  Marques -->
<section class="bg-white py-8">

    <div class="container mx-auto flex items-center flex-wrap pt-4 pb-12">

        <nav id="store" class="w-full z-30 top-0 px-6 py-1 mb-5">
            <div class="w-full container mx-auto flex flex-wrap items-center justify-center mt-0 px-2 py-3">

                <a aria-label="show more brands"
                    class="uppercase tracking-wide no-underline hover:no-underline font-bold text-gray-800 text-4xl  font-diph"
                    href="#">
                    Marques
                </a>


            </div>
        </nav>
        <?php if($brands): ?>
            <div class="flex flex-row space-x-2 space-y-2 w-full p-6  justify-center   flex-wrap">



                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div
                        class="w-full md:w-1/3 xl:w-1/4 p-6 text-center border border-gray-200 rounded-lg shadow hover:bg-gray-100  dark:border-gray-700 dark:hover:bg-gray-700 dark:hover:text-white">
                        <a aria-label="link to brand" href="/brand/<?php echo e($brand->id); ?>" class="text-center">


                            <?php if(file_exists('storage/' . $brand->image)): ?>
                                <?php $image = asset('storage/' . $brand->image); ?>
                            <?php else: ?>
                                <?php $image = $brand->image; ?>
                            <?php endif; ?>

                            <img class="hover:grow hover:shadow-lg  " alt="<?php echo e($brand->name); ?>" width="200"
                                height="200" style="display: inline; max-height:200px; height:200px"
                                src="<?php echo e($image); ?>">
                            <div class="pt-3 flex items-center justify-center justify-center font-cairo">
                                <p class="text-center " style="font-size: 25px; font-weight:bold"><?php echo e($brand->name); ?>

                                </p>

                            </div>

                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        <?php endif; ?>


    </div>

    <?php if(isset($showAll) && $showAll): ?>
        <div class="container w-full flex justify-center">
            <br>
            <?php echo e($brands->links()); ?>

        </div>
    <?php else: ?>
        <a aria-label="show more brands" href="all-brands" class="flex justify-center">

            <button aria-label="show all brands button"
                class=" font-cairo bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded">
                اظهار الكل
            </button>
        </a>
    <?php endif; ?>
</section>

<!-- End  Marques -->
<?php if(isset($showAll) && $showAll): ?>
    <?php echo $__env->make('shop.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/shop/brand/index.blade.php ENDPATH**/ ?>