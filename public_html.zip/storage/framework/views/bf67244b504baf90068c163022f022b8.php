<?php echo $__env->make('shop.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(!isset($isSearch)): ?>

    <?php if($settings?->slides): ?>
        <?php if(isset($settings?->slides[0]['slide'])): ?>
            <div class="swiper mySwiper mb-5">
                <div class="swiper-wrapper">

                    <?php $__currentLoopData = $settings?->slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i = 1;
                        $img = asset('storage/' . $slide['slide']);
                        $link = $slide['link']; ?>
                        <a aria-label="swiper link" class="swiper-slide" href="<?php echo e($link); ?>">
                            

                            <img src="<?php echo e($img); ?>" alt="shop swiper element" />

                            
                        </a>
                        <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
            <!-- Slider main container -->
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php if(isset($isSearch) && $isSearch): ?>

    <?php if($products->count() != 0): ?>
        <?php echo $__env->make('shop.product.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($brands->count() != 0): ?>
        <?php echo $__env->make('shop.brand.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($categories->count() != 0): ?>
        <?php echo $__env->make('shop.category.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php else: ?>
    <?php if($brands->count() != 0): ?>
        <?php echo $__env->make('shop.brand.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($categories->count() != 0): ?>
        <?php echo $__env->make('shop.category.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if($products->count() != 0): ?>
        <?php echo $__env->make('shop.product.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


<?php endif; ?>



<?php if($settings?->description): ?>
    <!-- <section class="bg-white py-8">

    <div class="container py-8 px-6 mx-auto text-center">

        <a class="uppercase tracking-wide no-underline hover:no-underline font-bold text-gray-800 text-5xl mb-8" href="#">
Description de la boutique
</a>

        <p class="mt-8 mb-8">
        <?php echo e($settings->description); ?>

        </p>
    </div>

</section> -->
<?php endif; ?>


<?php echo $__env->make('shop.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/shop/shop.blade.php ENDPATH**/ ?>