<?php echo $__env->make('shop.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(!isset($isSearch)): ?>

    <?php if($settings?->slides): ?>
        <?php if(isset($settings?->slides[0]['slide'])): ?>
            <?php echo $__env->make('shop.components.swiper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php if(isset($isSearch) && $isSearch): ?>

    <?php if($products->count() != 0): ?>
        <?php echo $__env->make('shop.product.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($brands->count() != 0): ?>
        <?php echo $__env->make('shop.brand.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($categories->count() != 0): ?>
        <?php echo $__env->make('shop.category.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php else: ?>
    <?php if($brands->count() != 0): ?>
        <?php echo $__env->make('shop.brand.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($categories->count() != 0): ?>
        <?php echo $__env->make('shop.category.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if($products->count() != 0): ?>
        <?php echo $__env->make('shop.product.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


<?php endif; ?>



<?php if($settings?->description): ?>
    <!-- <section class="">

    <div class="container px-6 py-8 mx-auto text-center">

        <a class="mb-8 text-5xl font-bold tracking-wide text-gray-800 no-underline uppercase hover:no-underline" href="#">
Description de la boutique
</a>

        <p class="mt-8 mb-8">
        <?php echo e($settings->description); ?>

        </p>
    </div>

</section> -->
<?php endif; ?>


<?php echo $__env->make('shop.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/shop/shop.blade.php ENDPATH**/ ?>