<style>
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@500&display=swap');

    * {
        font-family: 'Cairo', sans-serif;
    }

    .alert {
        padding: 5px;
        border: 1px solid rgb(7, 68, 7);
        background-color: rgb(159, 218, 159);
        color: white
    }

    .customer {
        padding: 5px;
        border: 1px solid rgb(7, 68, 7);
        background-color: rgb(255, 255, 255);
        color: rgba(17, 17, 15, 0.849)
    }
</style>

<div class="alert " role="alert">
    <b>Vous avez une nouvelle commande 😊</b>
</div>
<?php if($order->notes): ?>
    <div>
        <h3>Observation client</h3>
        <p>
            <?php echo e($order->notes); ?>

        </p>
    </div>
<?php endif; ?>
<div class="customer " role="alert">
    <h3>Produit :
    </h3>
    <b>Nom : </b> <?php echo e($productName); ?>

    <br>
    <b>Qte : </b> <?php echo e($quantity); ?>

    <br>
    <b>Cout de Livraison : </b>
    <?php echo e($order->shipping_price); ?>

    <br>
    <b>Prix Total: </b> <?php echo e($totalPrice); ?>

</div>

<div class="customer " role="alert">
    <h3>Client :
    </h3>
    <b>Nom : </b> <?php echo e($order->customer->name); ?>

    <br>
    <b>Address : </b> <?php echo e($order->customer->address); ?> - <?php echo e($order->customer->city); ?>

    <br>
    <b>contact : </b><a href="tel:<?php echo e($order->customer->phone); ?>"> <?php echo e($order->customer->phone); ?></a>
    <br>

    <b>Livraison : </b>

    <?php if($order->shipping_type == 'desk'): ?>
        Stop Desk
    <?php else: ?>
        Domicile
    <?php endif; ?>



</div>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/mail/order-placed.blade.php ENDPATH**/ ?>