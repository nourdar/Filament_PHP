<?php if($enabled): ?>
<?php if (! (empty($eventLayer->toArray()))): ?>
<!-- Meta Pixel Events -->
<script>
<?php $__currentLoopData = $eventLayer->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventName => $metaPixel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(empty($metaPixel['event_id']) && empty($metaPixel['data'])): ?>
    fbq('track', '<?php echo e($eventName); ?>');
<?php elseif(empty($metaPixel['event_id'])): ?>
    fbq('track', '<?php echo e($eventName); ?>', <?php echo json_encode($metaPixel['data']); ?>);
<?php else: ?>
    fbq('track', '<?php echo e($eventName); ?>', <?php echo json_encode($metaPixel['data']); ?>, {eventID: '<?php echo e($metaPixel['event_id']); ?>'});
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>
<!-- End Meta Pixel Events -->
<?php endif; ?>
<?php if (! (empty($customEventLayer->toArray()))): ?>
<!-- Meta Pixel Custom Events -->
<script>
<?php $__currentLoopData = $customEventLayer->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customEventName => $metaPixel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(empty($metaPixel['event_id']) && empty($metaPixel['data'])): ?>
   fbq('trackCustom', '<?php echo e($customEventName); ?>');
<?php elseif(empty($metaPixel['event_id'])): ?>
    fbq('trackCustom', '<?php echo e($customEventName); ?>', <?php echo json_encode($metaPixel['data']); ?>);
<?php else: ?>
   fbq('trackCustom', '<?php echo e($customEventName); ?>', <?php echo json_encode($metaPixel['data']); ?>, {eventID: '<?php echo e($metaPixel['event_id']); ?>'});
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>
<!-- End Meta Custom Pixel Events -->
<?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\vendor\combindma\laravel-facebook-pixel\src/../resources/views/body.blade.php ENDPATH**/ ?>