<?php

use App\Models\Settings;

$settings = Settings::first();

?>

<?php if($settings?->logo): ?>
    <img src="<?php echo e(asset('storage/' . $settings->logo)); ?>" alt="Logo" class="h-10" height="10">
<?php else: ?>
    <img src="<?php echo e(asset('images/logo-nameque.png')); ?>" alt="Logo" class="h-10" height="10">
<?php endif; ?>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>