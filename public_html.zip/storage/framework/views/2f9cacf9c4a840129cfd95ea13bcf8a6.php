
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/shop/components/show-product.blade.php ENDPATH**/ ?>