<div
    <?php echo e($attributes->class([
            'flex items-center rounded-lg shadow-sm ring-1 ring-gray-950/10 dark:ring-white/20',
        ])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\vendor\filament\support\src\/../resources/views/components/button/group.blade.php ENDPATH**/ ?>