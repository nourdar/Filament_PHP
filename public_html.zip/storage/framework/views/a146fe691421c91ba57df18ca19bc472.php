<?php use Illuminate\Support\Str; ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title ?? $settings?->name); ?></title>
    <meta name="description" content="<?php echo e($settings?->description); ?>">
    <meta name="keywords" content="<?php echo e($settings?->keywords); ?>">

    <meta property="og:title" content="<?php echo e($title ?? $settings?->name); ?>" />
    <?php if(isset($product) && !empty($product)): ?>
        <meta property="og:description" content="<?php echo e($product?->description); ?>" />
        <meta property="og:image" content="<?php echo e(asset('storage/' . $product?->image)); ?>" />
    <?php else: ?>
        <meta property="og:description" content="<?php echo e($settings?->description); ?>" />
        <meta property="og:image" content="<?php echo e(asset('storage/' . $settings?->logo)); ?>" />
    <?php endif; ?>

    <link rel="icon" type="image/png" href="<?php echo e(asset('storage/' . $settings?->logo)); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&family=Diphylleia&family=Work+Sans:wght@200&display=swap" rel="stylesheet">

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>


    <?php echo $__env->yieldPushContent('styles'); ?>

    <?php echo $__env->make('facebookpixel::head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $settings?->head_code; ?>

</head>


<?php if(isset($settings->style[0])): ?>
    <style>
        html {
  scroll-behavior: smooth !important;
}

        .font-diph {
            font-family: 'Diphylleia'  !important;
        }

        .font-cairo {
            font-family: 'cairo'  !important;
        }

        .font-work-sans {
            font-family: 'work sans'  !important;
        }

        .bg-btn-primary {
            background-color: <?php echo e($settings->style[0]['bg-btn-primary'] .' !important' ?? ''); ?>

        }

        select, input, form, textarea, .checkout-form{
            border-color : <?php echo e($settings->style[0]['bg-btn-primary'] .' !important' ?? ''); ?>

        }

        .bg-btn-primary:hover {
            background-color: <?php echo e($settings->style[0]['bg-btn-primary-hover'] .' !important'?? ''); ?>

        }

        .btn-primary-text-color {
            color: <?php echo e($settings->style[0]['btn-primary-text-color'] .' !important'?? 'white'); ?>

        }

        .btn-primary-text-color:hover {
            color: <?php echo e($settings->style[0]['btn-primary-text-color-hover'].' !important'?? 'white'); ?>

        }
    </style>
<?php endif; ?>



<body class="text-base leading-normal tracking-normal text-gray-600 bg-white font-cairo ">


    <?php echo $__env->make('facebookpixel::body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <?php echo $__env->make('shop.components.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('shop.components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('shop.components.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('shop.components.phone-call', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/shop/header.blade.php ENDPATH**/ ?>