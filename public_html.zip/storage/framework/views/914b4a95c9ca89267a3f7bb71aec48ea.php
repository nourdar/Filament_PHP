<?php echo $__env->make('shop.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .swiper {
        width: 100%;
        height: 100%;
    }

    .swiper-slide {
        text-align: center;
        font-size: 18px;
        background: #fff;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .swiper-slide img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: cover;
        margin: 4px
    }

    .markdown p {
        margin: 1em !important;
    }






    .productSwiper2 {
        height: 80%;
        width: 100%;
    }

    .productSwiper {
        height: 20%;
        box-sizing: border-box;
        padding: 10px 0;
    }

    .productSwiper .swiper-slide {
        width: 25%;
        height: 100%;
        opacity: 0.4;
    }

    .productSwiper .swiper-slide-thumb-active {
        opacity: 1;
    }


    @media screen and (max-width: 500px) {
        .swiper {
            width: 100%;
            height: 50%;

        }

        .productSwiper .swiper-slide {
        width: 25%;
        height: 50%;
        opacity: 0.4;
    }
        .swiper-slide  {
            width: 100%;

        }
        .swiper-slide img {
            width: 100%;
            object-fit: cover;

        }
        .swiper-button-next,.swiper-button-prev{

        }
    }
</style>


<?php if(Session::has('message')): ?>
    
    <?php if(Session::get('alert-class') == 'alert-success'): ?>
        




        <div class="fixed flex items-center justify-center h-5 bottom-12 right-5" style="z-index: 1">
            <div x-data="{ open: true }">
                <!-- Open modal button -->
                
                <!-- Modal Overlay -->
                <div x-show="open" class="fixed inset-0 z-10 flex items-center justify-center px-2 overflow-hidden ">
                    <div x-show="open" x-transition:enter="transition-opacity ease-out duration-300"
                        x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                        x-transition:leave="transition-opacity ease-in duration-300"
                        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
                        class="absolute inset-0 transition-opacity bg-gray-500 bg-opacity-75"></div>
                    <!-- Modal Content -->
                    <div x-show="open" x-transition:enter="transition-transform ease-out duration-300"
                        x-transition:enter-start="transform scale-75" x-transition:enter-end="transform scale-100"
                        x-transition:leave="transition-transform ease-in duration-300"
                        x-transition:leave-start="transform scale-100" x-transition:leave-end="transform scale-75"
                        class="z-50 w-full max-w-md overflow-hidden bg-white rounded-md shadow-xl sm:w-96 md:w-1/2 lg:w-2/3 xl:w-1/3">
                        <!-- Modal Header -->
                        <div class="flex justify-center px-4 py-2 text-white bg-green-500">
                            <h2 class="text-lg font-semibold text-center"></h2>
                        </div>
                        <!-- Modal Body -->
                        <div class="p-4 text-center">
                            <?php echo e(Session::get('message')); ?>

                        </div>
                        <!-- Modal Footer -->
                        <div class="flex justify-end px-4 py-2 border-t">
                            <button x-on:click="open = false"
                                class="w-full px-3 py-1 text-white bg-indigo-500 rounded-md sm:w-auto"> اغلاق </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        





        <div class="fixed flex items-center justify-center h-5 bottom-12 right-5" style="z-index: 1">
            <div x-data="{ open: true }">
                <!-- Open modal button -->
                
                <!-- Modal Overlay -->
                <div x-show="open" class="fixed inset-0 z-10 flex items-center justify-center px-2 overflow-hidden ">
                    <div x-show="open" x-transition:enter="transition-opacity ease-out duration-300"
                        x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                        x-transition:leave="transition-opacity ease-in duration-300"
                        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
                        class="absolute inset-0 transition-opacity bg-gray-500 bg-opacity-75"></div>
                    <!-- Modal Content -->
                    <div x-show="open" x-transition:enter="transition-transform ease-out duration-300"
                        x-transition:enter-start="transform scale-75" x-transition:enter-end="transform scale-100"
                        x-transition:leave="transition-transform ease-in duration-300"
                        x-transition:leave-start="transform scale-100" x-transition:leave-end="transform scale-75"
                        class="z-50 w-full max-w-md overflow-hidden bg-white rounded-md shadow-xl sm:w-96 md:w-1/2 lg:w-2/3 xl:w-1/3">
                        <!-- Modal Header -->
                        <div class="flex justify-center px-4 py-2 text-white bg-red-500">
                            <h2 class="text-lg font-semibold text-center"></h2>
                        </div>
                        <!-- Modal Body -->
                        <div class="p-4 text-center">
                            <?php echo e(Session::get('message')); ?>

                        </div>
                        <!-- Modal Footer -->
                        <div class="flex justify-end px-4 py-2 border-t">
                            <button x-on:click="open = false"
                                class="w-full px-3 py-1 text-white bg-indigo-500 rounded-md sm:w-auto"> اغلاق </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>



<?php echo $__env->make('shop.components.show-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class='container px-6 py-8 mx-auto'>

    <nav id="store" class="top-0 z-30 w-full mb-5">
        <div class="container flex flex-wrap items-center justify-center w-full mx-auto mt-0 ">

            <a aria-label="link to product"
                class="w-full text-2xl font-bold tracking-wide text-center text-gray-800 no-underline uppercase hover:no-underline font-diph "
                href="#">
                <?php echo e($product?->name); ?>


                <?php if(isset($product?->old_price)): ?>
                <br>
                <span class="m-2 text-xl text-red-900 line-through">
                    <?php echo e(number_format($product?->old_price, 0, '.')); ?>

                    DZD
                </span>
            <?php endif; ?>

                <br>
                <span class="text-4xl">

                    <?php echo e(number_format($product?->price, 0, '.')); ?>

                    DZD
                </span>


            </a>


        </div>
    </nav>


    <div class="flex flex-wrap lg:gap-x-5 lg:flex-nowrap">

        <div class="w-full lg:w-1/2 md:w-full" style="max-height: 500px">
            <!-- Swiper -->

            <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper productSwiper2">
                <div class="swiper-wrapper">

                    <?php if($product->image): ?>


                            <?php if(file_exists('storage/' . $product->image)): ?>
                                <?php $mainImage = asset('storage/' . $product->image); ?>
                            <?php else: ?>
                                <?php $mainImage = $product->image; ?>
                            <?php endif; ?>
                            <a href="<?php echo e($mainImage); ?>" class="swiper-slide">

                                <img src="<?php echo e($mainImage); ?>" alt="<?php echo e($product->name); ?>" class="w-full" />
                            </a>

                    <?php endif; ?>

                    <?php if($product->images): ?>

                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <?php if(file_exists('storage/' . $image)): ?>
                                    <?php $photo = asset('storage/' . $image); ?>
                                    <a href="<?php echo e($photo); ?>" class="swiper-slide">

                                        <img src="<?php echo e($photo); ?>" alt="<?php echo e($product->name); ?>" class="w-full" />
                                    </a>
                                <?php else: ?>
                                <a href="<?php echo e($image); ?>" class="swiper-slide">

                                    <img src="<?php echo e($image); ?>" alt="<?php echo e($product->name); ?>" class="w-full" />
                                </a>
                                <?php endif; ?>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


                </div>
                <div class="p-8 rounded swiper-button-next bg-slate-900 "></div>
                <div class="p-8 rounded swiper-button-prev bg-slate-900"></div>
            </div>
            <div thumbsSlider="" class="swiper productSwiper">
                <div class="swiper-wrapper">

                    <?php if($product->image): ?>
                        <div class="swiper-slide">
                            <img src="<?php echo e($mainImage); ?>" alt="<?php echo e($product->name); ?>" />
                        </div>
                    <?php endif; ?>

                    <?php if($product->images): ?>
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">

                                <?php if(file_exists('storage/' . $image)): ?>
                                    <?php $photo = asset('storage/' . $image); ?>

                                    <img src="<?php echo e($photo); ?>" />
                                <?php else: ?>
                                    <img src="<?php echo e($image); ?>" alt="<?php echo e($product->name); ?>" />
                                <?php endif; ?>


                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>


        <div class="w-full lg:w-1/2 md:w-full place-order-form">
            

            
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('ProductForm', ['productId' => $product->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-81512013-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            
        </div>

    </div>




    <br>
    <hr>

    <div class="mt-5 markdown font-cairo">
        <?php if($product?->videos): ?>
        <?php $__currentLoopData = $product?->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($video['link']) && !empty($video['link'])): ?>
        <div class="container">

                    <?php

                    $url_components = parse_url($video['link']);

                    parse_str($url_components['query'], $params);

                    $link = $params['v'] ?? '';

                    ?>

                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


    </div>

</div>

</div>






<?php if(isset($product['translations'][0])): ?>


    <?php if(isset($product['translations'][0]['image_landing'])): ?>
        <img src="<?php echo e(asset('storage/'. $product['translations'][0]['image_landing'])); ?>" class="landing-page-image" alt="">
    <?php endif; ?>

    <?php if(isset($product['translations'][0]['landing_image_link'])): ?>
        <img src="<?php echo e($product['translations'][0]['landing_image_link']); ?>" class="landing-page-image" alt="">
    <?php endif; ?>


    <?php if(isset($product['translations'][0]['description_arabic'])): ?>

    <div class="p-5 mt-12 mb-12 product-description"  dir="rtl">

        <?php echo Str::markdown($product['translations'][0]['description_arabic']); ?>

    </div>

    <?php endif; ?>



<?php endif; ?>


<?php if($product?->description): ?>
<div class="p-5 product-description" >

    <?php echo Str::markdown($product?->description); ?>

</div>
<?php endif; ?>




<?php echo $__env->make('shop.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






<script>
    document.addEventListener('livewire:init', () => {
        // Runs after Livewire is loaded but before it's initialized
        // on the page...
    })

    document.addEventListener('livewire:initialized', () => {

    window.onload = function() {

var swiper = new Swiper(".productSwiper", {
    loop: true,
    spaceBetween: 10,
    slidesPerView: 3,
    freeMode: true,
    watchSlidesProgress: true,
});


var swiper2 = new Swiper(".productSwiper2", {
    loop: true,
    spaceBetween: 10,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    thumbs: {
        swiper: swiper,
    },
});



}
    })
</script>



<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/shop/product/show.blade.php ENDPATH**/ ?>