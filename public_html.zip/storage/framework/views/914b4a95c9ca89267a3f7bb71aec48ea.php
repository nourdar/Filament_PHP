<?php echo $__env->make('shop.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    html,
    body {
        position: relative;
        height: 100%;
    }

    body {
        background: #eee;
        font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
        font-size: 14px;
        color: #000;
        margin: 0;
        padding: 0;
    }

    .swiper {
        width: 100%;
        height: 100%;
    }

    .swiper-slide {
        text-align: center;
        font-size: 18px;
        background: #fff;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .swiper-slide img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: contain;
    }

    .markdown p {
        margin: 1em !important;
    }






    .productSwiper2 {
        height: 80%;
        width: 100%;
    }

    .productSwiper {
        height: 20%;
        box-sizing: border-box;
        padding: 10px 0;
    }

    .productSwiper .swiper-slide {
        width: 25%;
        height: 100%;
        opacity: 0.4;
    }

    .productSwiper .swiper-slide-thumb-active {
        opacity: 1;
    }


    @media screen and (max-width: 500px) {
        .swiper {
            width: 100%;
            height: 50%;
        }

        .swiper-slide img {

            object-fit: contain;
        }
    }
</style>


<?php if(Session::has('message')): ?>
    
    <?php if(Session::get('alert-class') == 'alert-success'): ?>
        




        <div class="flex justify-center items-center h-5 fixed bottom-12 right-5" style="z-index: 99999">
            <div x-data="{ open: true }">
                <!-- Open modal button -->
                
                <!-- Modal Overlay -->
                <div x-show="open" class="fixed inset-0 px-2 z-10 overflow-hidden flex items-center justify-center ">
                    <div x-show="open" x-transition:enter="transition-opacity ease-out duration-300"
                        x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                        x-transition:leave="transition-opacity ease-in duration-300"
                        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
                        class="absolute inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
                    <!-- Modal Content -->
                    <div x-show="open" x-transition:enter="transition-transform ease-out duration-300"
                        x-transition:enter-start="transform scale-75" x-transition:enter-end="transform scale-100"
                        x-transition:leave="transition-transform ease-in duration-300"
                        x-transition:leave-start="transform scale-100" x-transition:leave-end="transform scale-75"
                        class="bg-white rounded-md shadow-xl overflow-hidden max-w-md w-full sm:w-96 md:w-1/2 lg:w-2/3 xl:w-1/3 z-50">
                        <!-- Modal Header -->
                        <div class="bg-green-500 text-white px-4 py-2 flex justify-center">
                            <h2 class="text-lg font-semibold text-center"></h2>
                        </div>
                        <!-- Modal Body -->
                        <div class="p-4 text-center">
                            <?php echo e(Session::get('message')); ?>

                        </div>
                        <!-- Modal Footer -->
                        <div class="border-t px-4 py-2 flex justify-end">
                            <button x-on:click="open = false"
                                class="px-3 py-1 bg-indigo-500 text-white  rounded-md w-full sm:w-auto"> اغلاق </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        





        <div class="flex justify-center items-center h-5 fixed bottom-12 right-5" style="z-index: 99999">
            <div x-data="{ open: true }">
                <!-- Open modal button -->
                
                <!-- Modal Overlay -->
                <div x-show="open" class="fixed inset-0 px-2 z-10 overflow-hidden flex items-center justify-center ">
                    <div x-show="open" x-transition:enter="transition-opacity ease-out duration-300"
                        x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                        x-transition:leave="transition-opacity ease-in duration-300"
                        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
                        class="absolute inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
                    <!-- Modal Content -->
                    <div x-show="open" x-transition:enter="transition-transform ease-out duration-300"
                        x-transition:enter-start="transform scale-75" x-transition:enter-end="transform scale-100"
                        x-transition:leave="transition-transform ease-in duration-300"
                        x-transition:leave-start="transform scale-100" x-transition:leave-end="transform scale-75"
                        class="bg-white rounded-md shadow-xl overflow-hidden max-w-md w-full sm:w-96 md:w-1/2 lg:w-2/3 xl:w-1/3 z-50">
                        <!-- Modal Header -->
                        <div class="bg-red-500 text-white px-4 py-2 flex justify-center">
                            <h2 class="text-lg font-semibold text-center"></h2>
                        </div>
                        <!-- Modal Body -->
                        <div class="p-4 text-center">
                            <?php echo e(Session::get('message')); ?>

                        </div>
                        <!-- Modal Footer -->
                        <div class="border-t px-4 py-2 flex justify-end">
                            <button x-on:click="open = false"
                                class="px-3 py-1 bg-indigo-500 text-white  rounded-md w-full sm:w-auto"> اغلاق </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<div class='container py-8 px-6 mx-auto'>

    <nav id="store" class="w-full z-30 top-0 mb-5">
        <div class="w-full container mx-auto flex flex-wrap items-center justify-center mt-0 ">

            <a class="w-full uppercase text-center tracking-wide no-underline hover:no-underline font-bold text-gray-800 text-2xl "
                href="#">
                <?php echo e($product?->name); ?>

                <br>
                <?php echo e(number_format($product?->price, 0, '.')); ?>

                DZD

                <?php if(isset($product?->old_price)): ?>
                    <span class="text-red-900 line-through">
                        <?php echo e(number_format($product?->old_price, 0, '.')); ?>

                        DZD
                    </span>
                <?php endif; ?>
            </a>


        </div>
    </nav>


    <div class="flex flex-wrap lg:gap-x-5  lg:flex-nowrap">

        <div class="w-full lg:w-1/2  md:w-full" style="max-height: 500px">
            <!-- Swiper -->

            <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper productSwiper2">
                <div class="swiper-wrapper">

                    <?php if($product->image): ?>
                        <div class="swiper-slide">

                            <?php if(file_exists('storage/' . $product->image)): ?>
                                <?php $mainImage = asset('storage/' . $product->image); ?>
                            <?php else: ?>
                                <?php $mainImage = $product->image; ?>
                            <?php endif; ?>

                            <img src="<?php echo e($mainImage); ?>" />
                        </div>
                    <?php endif; ?>

                    <?php if($product->images): ?>

                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">

                                <?php if(file_exists('storage/' . $image)): ?>
                                    <?php $photo = asset('storage/' . $image); ?>

                                    <img src="<?php echo e($photo); ?>" />
                                <?php else: ?>
                                    <img src="<?php echo e($image); ?>" />
                                <?php endif; ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


                </div>
                <div class="swiper-button-next bg-slate-900 p-8 rounded"></div>
                <div class="swiper-button-prev bg-slate-900 p-8 rounded"></div>
            </div>
            <div thumbsSlider="" class="swiper productSwiper">
                <div class="swiper-wrapper">

                    <?php if($product->image): ?>
                        <div class="swiper-slide">
                            <img src="<?php echo e($mainImage); ?>" />
                        </div>
                    <?php endif; ?>

                    <?php if($product->images): ?>
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">

                                <?php if(file_exists('storage/' . $image)): ?>
                                    <?php $photo = asset('storage/' . $image); ?>

                                    <img src="<?php echo e($photo); ?>" />
                                <?php else: ?>
                                    <img src="<?php echo e($image); ?>" />
                                <?php endif; ?>


                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>


        <div class="w-full lg:w-1/2  md:w-full place-order-form">
            

            <?php echo $__env->make('shop.product.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
        </div>

    </div>




    <br>
    <hr>

    <div class="mt-5 markdown font-cairo">


        <?php if($product?->description): ?>
            <?php echo Str::markdown($product?->description); ?>

        <?php endif; ?>
    </div>

</div>

</div>

<?php echo $__env->make('shop.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    var swiper = new Swiper(".productSwiper", {
        loop: true,
        spaceBetween: 10,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
    });
    var swiper2 = new Swiper(".productSwiper2", {
        loop: true,
        spaceBetween: 10,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        thumbs: {
            swiper: swiper,
        },
    });
</script>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/shop/product/show.blade.php ENDPATH**/ ?>