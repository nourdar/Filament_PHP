<div>
    <a href="tel:<?php echo e($getState()); ?>"><?php echo e($getState()); ?></a>
</div>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/Admin/customer-phone-column.blade.php ENDPATH**/ ?>