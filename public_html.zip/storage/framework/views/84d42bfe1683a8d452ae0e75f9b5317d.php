<div>
    <!--[if BLOCK]><![endif]--><?php if(is_string($getState())): ?>

    <a href="tel:<?php echo e($getState()); ?>"><?php echo e($getState()); ?></a>

    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\test\ecommerce\filament\FP\resources\views/Admin/customer-phone-column.blade.php ENDPATH**/ ?>