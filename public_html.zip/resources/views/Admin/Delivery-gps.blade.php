<div>
    <a href="http://www.google.com/maps/place/{{ $getState() }}"  target="_blank">{{ $getState() }}</a>
</div>
