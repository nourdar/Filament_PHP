<div>
    <a href="tel:{{ $getState() }}">{{ $getState() }}</a>
</div>
