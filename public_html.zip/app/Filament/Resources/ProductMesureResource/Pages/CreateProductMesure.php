<?php

namespace App\Filament\Resources\ProductMesureResource\Pages;

use App\Filament\Resources\ProductMesureResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProductMesure extends CreateRecord
{
    protected static string $resource = ProductMesureResource::class;
}
