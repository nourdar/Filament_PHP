<?php

return [
    'call_now' => 'اتصل الآن',
    'call_now_desc' => ' انقر على الرقم لبدء مكالمتك',
    'order_placed_success_title' => ' تم تسجيل الطلب',
    'order_placed_success_message' => ' لقد تم إرسال طلبك بنجاح وسوف نقوم بالتواصل معك للتأكيد.',
    'order_placed_error_title' => ' خطأ',
    'order_placed_error_message' => ' لم يتم تقديم طلبك'
];
