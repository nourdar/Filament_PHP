<?php

return [
    'pagination' => [
        'next'  => 'Suivant',
        'previous'  => 'Précédent'
    ]
];
