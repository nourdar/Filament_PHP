<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Error-500 / Maintenace Mode</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/css/503.css')}}">

</head>

<body>
    <h5>Internal Server error !</h5>
    <h1>5</h1>
    <h1>00</h1>
    <div class="box">
        <span></span><span></span>
        <span></span><span></span>
        <span></span>
    </div>
    <div class="box">
        <span></span><span></span>
        <span></span><span></span>
        <span></span>
    </div>
    <p> We're unable to find out what's happening! We suggest you to
        <br />
        visit here later.
    </p>

</body>

</html>
