<?php

namespace App\Mail;

use App\Models\Order;
use App\Models\Settings;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Queue\SerializesModels;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Contracts\Queue\ShouldQueue;

class OrderPlaced extends Mailable
{
    use Queueable, SerializesModels;

    public $settings;
    /**
     * Create a new message instance.
     */
    public function __construct( public Order $order, )
    {
        $this->settings = Settings::first();
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {

        $subject = $this->order->customer->name;



        $subject .= " a passé une commande #".$this->order->id;

        return new Envelope(
            from: new Address(env('MAIL_FROM_ADDRESS', ''), env('MAIL_FROM_NAME', '')),
            subject: $subject
        );


    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'mail.order-placed',
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
