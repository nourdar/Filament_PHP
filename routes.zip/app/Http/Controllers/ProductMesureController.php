<?php

namespace App\Http\Controllers;

use App\Models\ProductMesure;
use App\Http\Requests\StoreProductMesureRequest;
use App\Http\Requests\UpdateProductMesureRequest;

class ProductMesureController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreProductMesureRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ProductMesure $productMesure)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ProductMesure $productMesure)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateProductMesureRequest $request, ProductMesure $productMesure)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ProductMesure $productMesure)
    {
        //
    }
}
