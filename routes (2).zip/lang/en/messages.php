<?php

return [
    'call_now' => 'call'
];
