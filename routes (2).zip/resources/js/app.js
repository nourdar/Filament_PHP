import './bootstrap';
import "./form.js";
import { livewire_hot_reload } from 'virtual:livewire-hot-reload'

// import Alpine from 'alpinejs'
import Swiper from "swiper/bundle";




// window.Alpine = Alpine

// Alpine.plugin(ToastComponent)
window.Swiper = Swiper

livewire_hot_reload();



// Alpine.start()



